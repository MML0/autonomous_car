'''
@ 2022, Copyright AVIS Engine
'''

SIMULATOR_IP = "127.0.0.1"
SIMULATOR_PORT = 25001


    
